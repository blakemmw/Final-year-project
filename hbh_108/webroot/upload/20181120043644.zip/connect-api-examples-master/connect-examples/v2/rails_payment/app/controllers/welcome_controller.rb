class WelcomeController < ApplicationController
  def index
    render layout: 'index'
  end
end
